#This is one of the exercises of Site https://quera.ir.

The name of Exercise is `فروشگاه` and you can read this question from the URL below:

url: https://quera.ir/problemset/technology/21211/